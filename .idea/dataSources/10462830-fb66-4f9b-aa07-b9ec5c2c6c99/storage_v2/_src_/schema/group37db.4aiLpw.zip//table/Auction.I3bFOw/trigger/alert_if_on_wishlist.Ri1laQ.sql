create definer = group37@`%` trigger alert_if_on_wishlist
    after INSERT
    on Auction
    for each row
BEGIN
INSERT INTO Alerts(alert_timestamp, alert_type, alert_message, auction_id, account_id)
 SELECT			NOW(),
				'Wishlist_Alerts',
				"An item on your wishlist is now up for auction",
				a.auction_id,
                w.account_id
     FROM Wishlist w, Auction a
     WHERE w.item_id = new.item_id and a.auction_id = new.auction_id;
END;

