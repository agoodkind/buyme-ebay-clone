create definer = group37@`%` trigger do_auto_bid_and_send_alerts
    before INSERT
    on Manually_Bid_On
    for each row
begin
    set @upper_limit = 0.0;
    set @auto_bidder_id = 0;
    set @auto_increment_amount = 1.0;
    set @max_bid = new.amount;

    select abo.account_id,
           max(abo.upper_limit)
           into @auto_bidder_id,
               @upper_limit
    from Account_Bids_On_Auction abo
    where abo.auction_id = new.auction_id
      and abo.upper_limit >= new.amount + @auto_increment_amount;


    # essentially we are making two bids, the first being the new.amount, and second being new.amount + 1 but by the higher limit bidder

    if (@upper_limit >= new.amount + @auto_increment_amount) then
        set @max_bid = new.amount + @auto_increment_amount;

        insert into Auto_Bid_On (amount, account_id, auction_id)
        VALUES (@max_bid, @auto_bidder_id, new.auction_id);

        update Account_Bids_On_Auction
        set current_bid = @max_bid
        where account_id = @auto_bidder_id;

        insert into Alerts(auction_id, account_id, alert_type, alert_message, alert_timestamp, bid_amount)
        select new.auction_id,
               abo.account_id,
               'Auto_Bid_Alerts',
               'An auction you are bidding on has received a new bid, we have automatically placed a new bid for you.',
               NOW(),
               @max_bid
        from Account_Bids_On_Auction abo
        where abo.auction_id = new.auction_id and abo.account_id = @auto_bidder_id;

    end if;

    update Auction
    set current_bid = @max_bid
    where auction_id = new.auction_id;


    update Account_Bids_On_Auction
    set current_bid = new.amount
    where account_id = new.account_id;

    insert into Alerts(auction_id, account_id, alert_type, alert_message, alert_timestamp, bid_amount)
    select new.auction_id,
           abo.account_id,
           'Bids_Alerts',
           'A new bid has been placed on an auction you are also bidding on participating in.',
           NOW(),
           @max_bid
    from Account_Bids_On_Auction abo
    where abo.auction_id = new.auction_id and abo.account_id <> @auto_bidder_id and abo.account_id <> new.account_id; # send an alert to all except the auto bidder and new bidder, who gets their own alert

end;

