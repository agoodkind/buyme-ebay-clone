create view Bids as select `m`.`amount` AS `amount`, `m`.`auction_id` AS `auction_id`, `m`.`account_id` AS `account_id`
                    from `group37db`.`Manually_Bid_On` `m`
                    union
                    select `a`.`amount` AS `amount`, `a`.`auction_id` AS `auction_id`, `a`.`account_id` AS `account_id`
                    from `group37db`.`Auto_Bid_On` `a`;

