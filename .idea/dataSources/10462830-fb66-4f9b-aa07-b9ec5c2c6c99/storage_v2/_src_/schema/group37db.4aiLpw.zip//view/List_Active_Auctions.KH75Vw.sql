create view List_Active_Auctions as
select `ac`.`first_name`       AS `first_name`,
       `ac`.`last_name`        AS `last_name`,
       `au`.`current_bid`      AS `current_bid`,
       `au`.`closing_datetime` AS `closing_datetime`,
       `au`.`start_datetime`   AS `start_datetime`,
       `ci`.`item_type`        AS `item_type`,
       `ci`.`item_name`        AS `item_name`,
       `au`.`auction_id`       AS `auction_id`
from `group37db`.`Auction` `au`
         join `group37db`.`Account` `ac`
         join `group37db`.`Clothing_Item` `ci`
         join `group37db`.`Account_Sells_In_Auction` `asi`
where ((`ac`.`id` = `asi`.`account_id`) and (`asi`.`auction_id` = `au`.`auction_id`) and
       (`au`.`item_id` = `ci`.`item_id`) and (now() < `au`.`closing_datetime`));

