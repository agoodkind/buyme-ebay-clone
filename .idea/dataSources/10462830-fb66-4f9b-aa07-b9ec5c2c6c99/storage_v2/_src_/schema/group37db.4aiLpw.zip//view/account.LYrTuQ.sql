create view account as
select `group37db`.`Account`.`email_address` AS `email_address`, `group37db`.`Account`.`password` AS `password`
from `group37db`.`Account`;

